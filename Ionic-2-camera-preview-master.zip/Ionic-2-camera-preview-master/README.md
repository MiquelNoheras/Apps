# Ionic 2 Camera Preview Example Updated to Ionic 2.0 final

Steps:
 1. Download Nodejs.
 2. Download git.
 3. type `npm install -g ionic cordova` in your command prompt.
 4. type `git clone https://github.com/TeamClouders/Ionic-2-camera-preview` in your command prompt.
 5. After cloning type `npm install` to install dependencies.
 6. Attach your Mobile Device (Android/IOS).
 7. If Android first type `adb devices` to check if  your device is avalible and Add Platform for yours example `ionic platform add android` OR `ios`
 8. If Device is avalible type `ionic run android` it will build and install on your android device.
 9. For IPhone build type `ionic build ios`  (only works when using Mac).
 10. open `XCODE` And deloy on your device or simmulator.

![Opening Camera](/images/1.png)

![Opening Image](/images/2.png)

Now You can Display your camera in your own Hybrid Application.

I made simple steps to show you can type Camera Preview code in Typescript.

It will Display Camera in your HTML view.

More Tutorials are comming soon...

Good Luck...!!
