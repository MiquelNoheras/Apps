Tutorial: 

### With the Ionic CLI:


```bash
$ npm install
$ ionic serve
```

